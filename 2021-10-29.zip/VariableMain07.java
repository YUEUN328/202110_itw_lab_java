package edu.java.variale07;

public class VariableMain07 {

	public static void main(String[] args) {
		//boolean 타입: true 또는 false을 저장하는 타입
		boolean b1 = 2 > 3;
		System.out.println(b1);
		
		boolean b2 = 2 < 3;
		System.out.println(b2);
	}

}
