package edu.java.intro02; 

public class CalcMain {  // 클래스 시작
	public static void main(String[] args ) {  // main method 시작
		System.out.println(100 + 200); 
		System.out.println(100 - 200);
		System.out.println(100 * 200);
		System.out.println(10 / 2);
		
		// 위 결과와 비교
		System.out.println("100 + 200");
		// 문자열(string): 문자들의 집합(sequence). ""로 묶음
		// 문자(character): 문자 (1개). ''로 묶음
		System.out.println('a'); // a 문자 (1개)
		System.out.println("a"); // 문자 1개로 이루어진 문자열

	}  // main method 끝
	
}  // 클래스 끝
