package edu.java.intro01; // 패키지 선언문

/* 문서화 주석
* 
*/
	
/* 
*/

public class IntroMain {

	// main method : 프로그램의 시작점
	// main method가 끝나면 프로그램이 종료됨
	public static void main(String[] args) {
		System.out.println("안녕하세요.");
		System.out.println("Hello, Java");
		// 모든 문장의 끝은 ;
		// 실행 단축키: Ctrl+F11
	}

}
